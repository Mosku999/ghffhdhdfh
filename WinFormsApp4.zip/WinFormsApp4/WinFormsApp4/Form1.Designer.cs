﻿namespace WinFormsApp4
{
    partial class DisplayFileList
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            imageList1 = new ImageList(components);
            btnLogin = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            SuspendLayout();
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = SystemColors.HotTrack;
            btnLogin.ForeColor = SystemColors.Control;
            btnLogin.Location = new Point(360, 335);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(249, 90);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "\r\nВойти";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += button2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(360, 182);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(249, 23);
            textBox1.TabIndex = 3;
            textBox1.Text = "Логин:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(360, 228);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(249, 23);
            textBox2.TabIndex = 4;
            textBox2.Text = "Пароль:";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // DisplayFileList
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(30, 30, 30);
            ClientSize = new Size(1029, 613);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(btnLogin);
            Margin = new Padding(2);
            Name = "DisplayFileList";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ImageList imageList1;
        private PictureBox pictureBox1;
        private Button btnLogin;
        private TextBox textBox1;
        private TextBox textBox2;
    }
}
