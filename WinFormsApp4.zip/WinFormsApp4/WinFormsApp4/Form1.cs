namespace WinFormsApp4
{
    public partial class DisplayFileList : Form
    {
        public DisplayFileList()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "�������� �����";
                folderBrowserDialog.ShowNewFolderButton = false;

                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    DisplayFile(folderBrowserDialog.SelectedPath);
                }
            }
        }

        private void DisplayFile(string folderPath)
        {
            // ��� ��� ��� ����������� ������
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // ��� ��� ��� pictureBox1
        }

        private void DisplayFileList_Load(object sender, EventArgs e)
        {
            // ��� ��� ��� �������� �����
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}